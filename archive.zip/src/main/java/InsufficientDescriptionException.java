public class InsufficientDescriptionException extends Exception{
}
